<?php
$title = "Tela 5";
include '../templates/header.php';
?>
<h2>Tela 5</h2>
<p>Bem-vindo à Tela 5. Aqui está um exemplo de conteúdo da página derivada.</p>
<div class="card">
    <h3>Informação Detalhada</h3>
    <p>Detalhes sobre a tela 5.</p>
</div>
<?php include '../templates/footer.php'; ?>

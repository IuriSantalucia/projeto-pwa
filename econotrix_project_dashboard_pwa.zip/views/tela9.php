<?php
$title = "Tela 9";
include '../templates/header.php';
?>
<h2>Tela 9</h2>
<p>Bem-vindo à Tela 9. Aqui está um exemplo de conteúdo da página derivada.</p>
<div class="card">
    <h3>Informação Detalhada</h3>
    <p>Detalhes sobre a tela 9.</p>
</div>
<?php include '../templates/footer.php'; ?>

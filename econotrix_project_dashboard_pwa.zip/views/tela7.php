<?php
$title = "Tela 7";
include '../templates/header.php';
?>
<h2>Tela 7</h2>
<p>Bem-vindo à Tela 7. Aqui está um exemplo de conteúdo da página derivada.</p>
<div class="card">
    <h3>Informação Detalhada</h3>
    <p>Detalhes sobre a tela 7.</p>
</div>
<?php include '../templates/footer.php'; ?>

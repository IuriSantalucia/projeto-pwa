document.addEventListener('DOMContentLoaded', () => {
    console.log("JavaScript carregado com sucesso!");
});

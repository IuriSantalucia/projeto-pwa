<?php
$title = "InvestmentUX - Dashboard";
include 'templates/header.php';
?>
<h2>Wallet</h2>
<div class="dashboard">
    <div class="card">
        <h3>Your Total Balance</h3>
        <p>$25,052.00</p>
    </div>
    <div class="card">
        <h3>Total Income</h3>
        <p>$5,560.50</p>
    </div>
    <div class="card">
        <h3>Total Expense</h3>
        <p>$3,586.15</p>
    </div>
    <canvas id="cashFlowChart" width="400" height="200"></canvas>
</div>

<script>
    const ctx = document.getElementById('cashFlowChart').getContext('2d');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
            datasets: [{
                label: 'Cash Flow',
                data: [12, 19, 3, 5, 2, 3],
                backgroundColor: 'rgba(0, 123, 255, 0.5)',
            }]
        },
        options: {
            responsive: true,
        }
    });
</script>
<?php include 'templates/footer.php'; ?>

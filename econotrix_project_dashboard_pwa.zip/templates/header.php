<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/econotrix_project_dashboard/assets/css/style.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="/econotrix_project_dashboard/assets/js/main.js" defer></script>
    <title><?php echo $title ?? 'InvestmentUX'; ?></title>
</head>
<body>
    <div class="app-container">
        <aside class="sidebar">
            <div class="logo">InvestmentUX</div>
            <nav class="menu">
                <a href="/econotrix_project_dashboard/index.php" class="<?php echo $title === 'Dashboard' ? 'active' : ''; ?>">
                    <span>&#128200;</span> Dashboard</a>
                <a href="/econotrix_project_dashboard/views/tela2.php" class="<?php echo $title === 'Wallet' ? 'active' : ''; ?>">
                    <span>&#128181;</span> Wallet</a>
                <a href="/econotrix_project_dashboard/views/tela3.php" class="<?php echo $title === 'My Goals' ? 'active' : ''; ?>">
                    <span>&#127919;</span> My Goals</a>
                <a href="/econotrix_project_dashboard/views/tela4.php" class="<?php echo $title === 'Loans' ? 'active' : ''; ?>">
                    <span>&#128736;</span> Loans</a>
                <a href="/econotrix_project_dashboard/views/tela5.php" class="<?php echo $title === 'Statistics' ? 'active' : ''; ?>">
                    <span>&#128202;</span> Statistics</a>
                <a href="/econotrix_project_dashboard/views/tela6.php" class="<?php echo $title === 'Settings' ? 'active' : ''; ?>">
                    <span>&#9881;</span> Settings</a>
            </nav>
        </aside>
        <main class="content">
